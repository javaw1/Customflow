#include "discord_rpc_init.h"
#include <ctime>

void Discord::Initialize()
{
    DiscordEventHandlers Handle;
    memset(&Handle, 0, sizeof(Handle));
    Discord_Initialize("1160216284491960390", &Handle, 1, NULL);
}

void Discord::Update()
{
    DiscordRichPresence discordPresence;
    memset(&discordPresence, 0, sizeof(discordPresence));
    static auto elapsed = std::time(nullptr);

    discordPresence.largeImageText = "test1";
    discordPresence.state = "test2";
    discordPresence.largeImageKey = "test3";
    discordPresence.startTimestamp = elapsed;
    discordPresence.smallImageKey = "test4";
    discordPresence.smallImageText = "test5";
    discordPresence.button1_label = "Discord Gyrbix"; // �� �� � ������� �������� =)
    discordPresence.button1_url = "https://discord.gg/rzF7bNWUub";
    discordPresence.button2_label = "Discord LordHappy";
    discordPresence.button2_url = "https://discord.gg/38JjevGggf";
    Discord_UpdatePresence(&discordPresence);
}