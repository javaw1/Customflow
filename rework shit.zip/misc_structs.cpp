#include "globals.hpp"

namespace structs
{

}