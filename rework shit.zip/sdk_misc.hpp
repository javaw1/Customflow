#pragma once
#include "checksum_crc32.hpp"
#include "md5_pseudo_random.hpp"