#include "discord_rpc_init.h"
#include <ctime>

void Discord::Initialize()
{
    DiscordEventHandlers Handle;
    memset(&Handle, 0, sizeof(Handle));
    Discord_Initialize("1160216284491960390", &Handle, 1, NULL);
}

void Discord::Update()
{
    DiscordRichPresence discordPresence;
    memset(&discordPresence, 0, sizeof(discordPresence));
    static auto elapsed = std::time(nullptr);

    discordPresence.largeImageText = "Lordhappy gay";
    discordPresence.state = "";
    discordPresence.largeImageKey = "customflow";
    discordPresence.startTimestamp = elapsed;
    discordPresence.smallImageKey = "";
    discordPresence.smallImageText = "Customflow.su";
    discordPresence.button1_label = "Discord Customflow.su"; // �� �� � ������� �������� =)
    discordPresence.button1_url = "https://discord.gg/E8m8Tw5X5M";
    discordPresence.button2_label = "Website";
    discordPresence.button2_url = "airflow.pw";
    Discord_UpdatePresence(&discordPresence);
}