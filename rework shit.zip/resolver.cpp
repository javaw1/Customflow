﻿#include "globals.hpp"
#include "resolver.hpp"
#include "animations.hpp"
#include "server_bones.hpp"
#include "ragebot.hpp"
#include "penetration.hpp"

namespace resolver
{
	inline void prepare_jitter(c_cs_player* player, resolver_info_t& resolver_info, anim_record_t* current)
	{
		auto& jitter = resolver_info.jitter;
		jitter.yaw_cache[jitter.yaw_cache_offset % YAW_CACHE_SIZE] = current->eye_angles.y;

		if (jitter.yaw_cache_offset >= YAW_CACHE_SIZE + 1)
			jitter.yaw_cache_offset = 0;
		else
			jitter.yaw_cache_offset++;

		for (int i = 0; i < YAW_CACHE_SIZE - 1; ++i)
		{
			float diff = std::fabsf(jitter.yaw_cache[i] - jitter.yaw_cache[i + 1]);
			if (diff <= 0.f)
			{
				if (jitter.static_ticks < 3)
					jitter.static_ticks++;
				else
					jitter.jitter_ticks = 0;
			}
			else if (diff >= 30.f)
			{
				if (jitter.jitter_ticks < 3)
					jitter.jitter_ticks++;
				else
					jitter.static_ticks = 0;
			}
		}

		jitter.is_jitter = jitter.jitter_ticks > jitter.static_ticks;
	}

	inline vec3_t get_point_direction(c_cs_player* player)
	{
		vec3_t fw{};

		float at_target_yaw = math::calc_angle(HACKS->local->origin(), player->origin()).y;
		math::calc_angle(vec3_t(0, at_target_yaw - 90.f, 0), fw);

		return fw;
	}

	inline void prepare_freestanding(c_cs_player* player)
	{
		auto& info = resolver_info[player->index()];
		auto& jitter = info.jitter;
		auto& freestanding = info.freestanding;

		auto layers = player->animlayers();

		if (!layers || !HACKS->weapon_info || !HACKS->local || !HACKS->local->is_alive() || player->is_bot() || !g_cfg.rage.resolver)
		{
			if (freestanding.updated)
				freestanding.reset();

			return;
		}

		auto weight = layers[6].weight;
		if (jitter.is_jitter || weight > 0.75f)
		{
			if (freestanding.updated)
				freestanding.reset();

			return;
		}

		auto& cache = player->bone_cache();
		if (!cache.count() || !cache.base())
			return;

		freestanding.updated = true;

		bool inverse_side{};
		{
			float at_target = math::normalize_yaw(math::calc_angle(HACKS->local->origin(), player->get_abs_origin()).y);
			float angle = math::normalize_yaw(player->eye_angles().y);

			const bool sideways_left = std::abs(math::normalize_yaw(angle - math::normalize_yaw(at_target - 90.f))) < 45.f;
			const bool sideways_right = std::abs(math::normalize_yaw(angle - math::normalize_yaw(at_target + 90.f))) < 45.f;

			bool forward = std::abs(math::normalize_yaw(angle - math::normalize_yaw(at_target + 180.f))) < 45.f;
			inverse_side = forward && !(sideways_left || sideways_right);
		}

		auto direction = get_point_direction(player);

		static matrix3x4_t predicted_matrix[128]{};
		std::memcpy(predicted_matrix, cache.base(), sizeof(predicted_matrix));

		auto store_changed_matrix_data = [&](const vec3_t& new_position, bullet_t& out)
			{
				auto old_abs_origin = player->get_abs_origin();

				math::change_bones_position(predicted_matrix, 128, player->origin(), new_position);
				{
					static matrix3x4_t old_cache[128]{};
					player->store_bone_cache(old_cache);
					{
						player->set_abs_origin(new_position);
						player->set_bone_cache(predicted_matrix);

						auto head_pos = cache.base()[8].get_origin();
						out = penetration::simulate(HACKS->local, player, ANIMFIX->get_local_anims()->eye_pos, head_pos);
					}
					player->set_bone_cache(old_cache);
				}
				math::change_bones_position(predicted_matrix, 128, new_position, player->origin());
			};

		{

			bullet_t left{}, right{};

			auto left_dir = inverse_side ? (player->origin() + direction * 40.f) : (player->origin() - direction * 40.f);
			store_changed_matrix_data(left_dir, left);

			auto right_dir = inverse_side ? (player->origin() - direction * 40.f) : (player->origin() + direction * 40.f);
			store_changed_matrix_data(right_dir, right);

			if (left.damage > right.damage)
				freestanding.side = 1;
			else if (left.damage < right.damage)
				freestanding.side = -1;

			if (freestanding.side)
				freestanding.updated = true;
		}
	}

	inline float build_server_abs_yaw(c_cs_player* player, float angle) //skeet
	{
		vec3_t velocity = player->velocity();
		auto anim_state = player->animstate();
		float m_flEyeYaw = angle;
		float m_flGoalFeetYaw = 0.f;

		float eye_feet_delta = math::angle_diff(m_flEyeYaw, m_flGoalFeetYaw);

		static auto GetSmoothedVelocity = [](float min_delta, vec3_t a, vec3_t b) {
			vec3_t delta = a - b;
			float delta_length = delta.length();

			if (delta_length <= min_delta)
			{
				vec3_t result;

				if (-min_delta <= delta_length)
					return a;
				else
				{
					float iradius = 1.0f / (delta_length + FLT_EPSILON);
					return b - ((delta * iradius) * min_delta);
				}
			}
			else
			{
				float iradius = 1.0f / (delta_length + FLT_EPSILON);
				return b + ((delta * iradius) * min_delta);
			}
			};

		float spd = velocity.length_sqr();

		if (spd > std::powf(1.2f * 260.0f, 2.f))
		{
			vec3_t velocity_normalized = velocity.normalized();
			velocity = velocity_normalized * (1.2f * 260.0f);
		}

		float m_flChokedTime = anim_state->last_update_time;
		float v25 = std::clamp(player->duck_amount() + anim_state->duck_additional, 0.0f, 1.0f);
		float v26 = anim_state->anim_duck_amount;
		float v27 = m_flChokedTime * 6.0f;
		float v28;

		// clamp
		if ((v25 - v26) <= v27) {
			if (-v27 <= (v25 - v26))
				v28 = v25;
			else
				v28 = v26 - v27;
		}
		else {
			v28 = v26 + v27;
		}

		float flDuckAmount = std::clamp(v28, 0.0f, 1.0f);

		vec3_t animationVelocity = math::GetSmoothedVelocity(m_flChokedTime * 2000.0f, velocity, player->velocity());
		float speed = std::fminf(animationVelocity.length(), 260.0f);

		float flMaxMovementSpeed = 260.0f;

		float flRunningSpeed = speed / (flMaxMovementSpeed * 0.520f);
		float flDuckingSpeed = speed / (flMaxMovementSpeed * 0.340f);

		flRunningSpeed = std::clamp(flRunningSpeed, 0.0f, 1.0f);

		float flYawModifier = (((anim_state->walk_run_transition * -0.30000001) - 0.19999999) * flRunningSpeed) + 1.0f;

		if (flDuckAmount > 0.0f)
		{
			float flDuckingSpeed = std::clamp(flDuckingSpeed, 0.0f, 1.0f);
			flYawModifier += (flDuckAmount * flDuckingSpeed) * (0.5f - flYawModifier);
		}

		const float v60 = -58.f;
		const float v61 = 58.f;

		float flMinYawModifier = v60 * flYawModifier;
		float flMaxYawModifier = v61 * flYawModifier;

		if (eye_feet_delta <= flMaxYawModifier)
		{
			if (flMinYawModifier > eye_feet_delta)
				m_flGoalFeetYaw = fabs(flMinYawModifier) + m_flEyeYaw;
		}
		else
		{
			m_flGoalFeetYaw = m_flEyeYaw - fabs(flMaxYawModifier);
		}

		math::normalize_yaw(m_flGoalFeetYaw);

		if (speed > 0.1f || fabs(velocity.z) > 100.0f)
		{
			m_flGoalFeetYaw = math::approach_angle(
				m_flEyeYaw,
				m_flGoalFeetYaw,
				((anim_state->walk_run_transition * 20.0f) + 30.0f)
				* m_flChokedTime);
		}
		else
		{
			m_flGoalFeetYaw = math::approach_angle(
				player->lower_body_yaw(),
				m_flGoalFeetYaw,
				m_flChokedTime * 100.0f);
		}

		return m_flGoalFeetYaw;
	}

	inline void prepare_side(c_cs_player* player, anim_record_t* current, anim_record_t* previous)
	{
		auto& info = resolver_info[player->index()];
		if (!HACKS->weapon_info || !HACKS->local || !HACKS->local->is_alive() || current->choke < 2 || player->is_bot() || !g_cfg.rage.resolver)
		{
			if (info.resolved)
				info.reset();

			return;
		}

		auto hdr = player->get_studio_hdr();
		if (!hdr)
			return;

		if (current->choke < 2)
			info.add_legit_ticks();
		else
			info.add_fake_ticks();

		if (info.is_legit())
		{
			info.resolved = false;
			info.mode = XOR("no fake");
			return;
		}

		prepare_jitter(player, info, current);
		prepare_freestanding(player);
		auto& jitter = info.jitter;
		auto& freestanding = info.freestanding;

		if (!info.anim_resolve_ticks || std::abs(HACKS->global_vars->tickcount - info.anim_resolve_ticks) >= current->choke)
		{
			if (jitter.is_jitter)
			{
				float first_angle = math::normalize_yaw(jitter.yaw_cache[YAW_CACHE_SIZE - 1]);
				float second_angle = math::normalize_yaw(jitter.yaw_cache[YAW_CACHE_SIZE - 2]);

				float _first_angle = std::sin(DEG2RAD(first_angle));
				float _second_angle = std::sin(DEG2RAD(second_angle));

				float __first_angle = std::cos(DEG2RAD(first_angle));
				float __second_angle = std::cos(DEG2RAD(second_angle));

				float avg_yaw = math::normalize_yaw(RAD2DEG(std::atan2f((_first_angle + _second_angle) / 4.f, (__first_angle + __second_angle) / 4.f)));
				float diff = math::normalize_yaw(current->eye_angles.y - avg_yaw);

				info.resolved = true;
				info.mode = XOR("jitter");
				info.side = diff > 0.f ? -1 : 1;
			}
			else
			{
				if (freestanding.updated)
				{
					info.resolved = true;
					info.mode = XOR("freestanding");
					info.side = freestanding.side;
				}
			}
		}
		if ( previous )
		{
			if (static_cast<int>(current->layers[6].weight * 1000.f) == static_cast<int>(previous->layers[6].weight * 1000.f))
			{
				const auto& cur_layer6 = current->layers[6];

				const auto zero_delta = std::abs(cur_layer6.playback_rate - current->matrix_zero.layers[6].playback_rate);
				const auto left_delta = std::abs(cur_layer6.playback_rate - current->matrix_left.layers[6].playback_rate);
				const auto right_delta = std::abs(cur_layer6.playback_rate - current->matrix_right.layers[6].playback_rate);

				const auto min_delta = std::min(zero_delta, std::min(left_delta, right_delta));

				if (static_cast<int>(min_delta * 1000.f) == static_cast<int>(left_delta * 1000.f))
				{
					info.anim_resolve_ticks = HACKS->global_vars->tickcount;

					info.resolved = true;
					info.mode = XOR("layers");
					info.side = -1;
				}
				else if (static_cast<int>(min_delta * 1000.f) == static_cast<int>(right_delta * 1000.f))
				{
					info.anim_resolve_ticks = HACKS->global_vars->tickcount;

					info.resolved = true;
					info.mode = XOR("layers");
					info.side = 1;
				}
			}
		}
		else
		{
			if (RAGEBOT->m_missed_prev_side[player->index()] == 1)
				info.side = -1;
			else if (RAGEBOT->m_missed_prev_side[player->index()] == -1)
				info.side = 1;
			else if (RAGEBOT->m_missed_prev_side[player->index()] == 0)
				info.side = math::random_int(0, 1) ? -1 : 1;
			info.mode = XOR("static");	
		}

		info.resolved = true;
	}

	inline void apply_side(c_cs_player* player, anim_record_t* current, int choke)
	{
		auto& info = resolver_info[player->index()];

		if (!HACKS->weapon_info || !HACKS->local || !HACKS->local->is_alive() || !info.resolved || info.side == 1337 || player->is_teammate(false))
			return;

		auto state = player->animstate();
		if (!state)
		   return;

		
		state->abs_yaw = math::normalize_yaw(player->eye_angles().y + state->get_max_rotation() * info.side);
	}
}