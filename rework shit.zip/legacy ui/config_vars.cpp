#include "../globals.hpp"
#include "config_vars.h"

configs_t g_cfg = {};